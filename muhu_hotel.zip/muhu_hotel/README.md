# MUHU Hotel — เว็บจองห้องพัก (Django)

## วิธีรัน
```bash
pip install -r requirements.txt
python manage.py makemigrations hotel
python manage.py migrate
python manage.py seed          # สร้างประเภทห้อง, ห้อง 50 ห้อง, ผู้ดูแล admin / admin12345
python manage.py runserver
```
- หน้าลูกค้า: http://127.0.0.1:8000/
- หน้าผู้ดูแลระบบ: http://127.0.0.1:8000/manage/  (admin / admin12345 — ควรเปลี่ยนรหัสผ่าน)

## หมายเหตุ
- ราคา/ความจุของประเภทห้อง (1,500 / 2,800 / 5,500 บาท) เป็นค่าตัวอย่าง แก้ได้ที่เมนู "ข้อมูลห้องพัก"
- ข้อความหน้าข้อมูลโรงแรม, สิ่งอำนวยความสะดวก, โปรโมชั่น และข้อมูลติดต่อเป็นตัวอย่าง แก้ไขใน hotel/templates/hotel/
- การชำระเงินด้วยบัตร/QR เป็นหน้าจำลองผล (ยังไม่เชื่อมผู้ให้บริการจริง)
- อีเมลยืนยันการจองแสดงใน Terminal (console backend) — ตั้งค่า SMTP ใน muhu/settings.py เมื่อใช้งานจริง
