from .models import Booking, HK_OOO, Room

ACTIVE_STATUSES = [Booking.PENDING, Booking.CONFIRMED]


def available_rooms(check_in, check_out, exclude_booking=None):
    """ห้องที่ว่างในช่วงวันที่กำหนด (ป้องกันการจองทับซ้อน และตัดห้องที่ซ่อมบำรุง)"""
    busy = Booking.objects.filter(
        status__in=ACTIVE_STATUSES, check_in__lt=check_out, check_out__gt=check_in
    )
    if exclude_booking is not None and exclude_booking.pk:
        busy = busy.exclude(pk=exclude_booking.pk)
    return Room.objects.exclude(hk_status=HK_OOO).exclude(id__in=list(busy.values_list("room_id", flat=True)))
