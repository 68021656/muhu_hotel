from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand

from hotel.models import Room, RoomType

# สถานะแม่บ้าน: 1=Clean, 2=Dirty, 3=Cleaning, 4=Out of Order
FLOORS = [
    ("Standard - ชั้น 1", 1, ["101", "102", "103", "104", "105", "106", "107", "108", "109", "110"], [1, 1, 2, 3, 1, 1, 2, 1, 4, 1]),
    ("Standard - ชั้น 2", 1, ["201", "202", "203", "204", "205", "206", "207", "208", "209", "210"], [1, 2, 2, 1, 3, 1, 1, 2, 1, 1]),
    ("Standard - ชั้น 3", 1, ["301", "302", "303", "304", "305", "306", "307", "308", "309", "310"], [1, 1, 2, 1, 3, 1, 1, 2, 1, 4]),
    ("Deluxe - ชั้น 4", 2, ["401", "402", "403", "404", "405", "406", "407", "408", "409", "410"], [1, 1, 2, 1, 1, 3, 1, 2, 1, 1]),
    ("Deluxe - ชั้น 5", 2, ["501", "502", "503", "504", "505"], [1, 2, 1, 3, 1]),
    ("Suite - โซนวิลล่า", 3, ["V01", "V02", "V03", "V04", "V05"], [1, 1, 2, 1, 1]),
]
REPAIR = {"109": "ซ่อมแอร์", "310": "ซ่อมท่อน้ำ"}


class Command(BaseCommand):
    help = "สร้างข้อมูลเริ่มต้น: ประเภทห้อง, ห้องพัก 50 ห้อง และบัญชีผู้ดูแลระบบ"

    def handle(self, *args, **options):
        types = {}
        for key, name, price, cap, desc in [
            (1, "Standard Room", 1500, 2, "ห้องมาตรฐาน สะอาด สบาย เหมาะกับการพักผ่อนทุกวัน"),
            (2, "Deluxe Sea View", 2800, 3, "ห้องดีลักซ์ วิวทะเล ชั้น 4-5"),
            (3, "Family Suite", 5500, 5, "ห้องสวีทโซนวิลล่าส่วนตัว เหมาะสำหรับครอบครัว"),
        ]:
            types[key], _ = RoomType.objects.get_or_create(
                id=key, defaults={"name": name, "price": price, "capacity": cap, "description": desc}
            )
        for label, tid, numbers, statuses in FLOORS:
            for number, st in zip(numbers, statuses):
                note = label + (f" ({REPAIR[number]})" if number in REPAIR else "")
                Room.objects.get_or_create(
                    number=number, defaults={"room_type": types[tid], "hk_status": st, "note": note}
                )
        User = get_user_model()
        if not User.objects.filter(username="admin").exists():
            User.objects.create_superuser("admin", "admin@muhuhotel.example", "admin12345")
            self.stdout.write("สร้างผู้ดูแลระบบ: admin / admin12345 (กรุณาเปลี่ยนรหัสผ่าน)")
        self.stdout.write(self.style.SUCCESS(f"พร้อมใช้งาน: ห้องพักทั้งหมด {Room.objects.count()} ห้อง"))
