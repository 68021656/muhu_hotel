from django.db import models

HK_CLEAN, HK_DIRTY, HK_CLEANING, HK_OOO = 1, 2, 3, 4
HK_CHOICES = [
    (HK_CLEAN, "Clean (พร้อมใช้งาน)"),
    (HK_DIRTY, "Dirty (รอทำความสะอาด)"),
    (HK_CLEANING, "Cleaning (กำลังทำความสะอาด)"),
    (HK_OOO, "Out of Order (ซ่อมบำรุง)"),
]


class RoomType(models.Model):
    name = models.CharField("ชื่อประเภทห้อง", max_length=100)
    description = models.TextField("รายละเอียด", blank=True)
    price = models.DecimalField("ราคาต่อคืน (บาท)", max_digits=10, decimal_places=2)
    capacity = models.PositiveSmallIntegerField("รองรับผู้เข้าพัก (คน)", default=2)

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return self.name


class Room(models.Model):
    number = models.CharField("เลขห้อง", max_length=10, unique=True)
    room_type = models.ForeignKey(RoomType, verbose_name="ประเภทห้อง", on_delete=models.PROTECT, related_name="rooms")
    hk_status = models.PositiveSmallIntegerField("สถานะแม่บ้าน", choices=HK_CHOICES, default=HK_CLEAN)
    note = models.CharField("หมายเหตุ (โซน/ชั้น)", max_length=200, blank=True)
    assigned_to = models.CharField("แม่บ้านที่รับผิดชอบ", max_length=100, blank=True)

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return self.number


class Guest(models.Model):
    """ข้อมูลสมาชิก / ผู้จอง"""
    name = models.CharField("ชื่อ-นามสกุล", max_length=150)
    phone = models.CharField("เบอร์โทรศัพท์", max_length=20)
    email = models.EmailField("อีเมล")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-id"]

    def __str__(self):
        return f"{self.name} ({self.phone})"


class Booking(models.Model):
    PENDING, CONFIRMED, CANCELLED = "pending", "confirmed", "cancelled"
    STATUS_CHOICES = [(PENDING, "รอยืนยัน"), (CONFIRMED, "ยืนยันแล้ว"), (CANCELLED, "ยกเลิก")]

    reference = models.CharField("เลขที่การจอง", max_length=20, blank=True)
    guest = models.ForeignKey(Guest, on_delete=models.PROTECT, related_name="bookings")
    room = models.ForeignKey(Room, verbose_name="ห้องพัก", on_delete=models.PROTECT, related_name="bookings")
    check_in = models.DateField("วันเข้าพัก")
    check_out = models.DateField("วันออก")
    guests = models.PositiveSmallIntegerField("จำนวนผู้เข้าพัก", default=1)
    total = models.DecimalField("ยอดรวม (บาท)", max_digits=12, decimal_places=2, default=0)
    status = models.CharField("สถานะ", max_length=12, choices=STATUS_CHOICES, default=PENDING)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-id"]

    @property
    def nights(self):
        return (self.check_out - self.check_in).days

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if not self.reference:
            self.reference = f"MH{self.created_at:%y%m%d}{self.pk:04d}"
            super().save(update_fields=["reference"])

    def __str__(self):
        return self.reference


class Payment(models.Model):
    TRANSFER, CARD, QR, CASH = "transfer", "card", "qr", "cash"
    METHOD_CHOICES = [
        (TRANSFER, "โอนเงินผ่านธนาคาร"),
        (CARD, "บัตรเครดิต / เดบิต"),
        (QR, "QR PromptPay"),
        (CASH, "เงินสดที่โรงแรม"),
    ]
    PENDING, PAID, FAILED = "pending", "paid", "failed"
    STATUS_CHOICES = [(PENDING, "รอชำระเงิน"), (PAID, "ชำระเงินแล้ว"), (FAILED, "ไม่สำเร็จ")]

    booking = models.OneToOneField(Booking, on_delete=models.CASCADE, related_name="payment")
    method = models.CharField("ช่องทางชำระเงิน", max_length=10, choices=METHOD_CHOICES, blank=True)
    status = models.CharField("สถานะการชำระเงิน", max_length=10, choices=STATUS_CHOICES, default=PENDING)
    amount = models.DecimalField("ยอดเงิน (บาท)", max_digits=12, decimal_places=2, default=0)
    slip = models.FileField("สลิปโอนเงิน", upload_to="slips/", blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.booking.reference} - {self.get_status_display()}"
