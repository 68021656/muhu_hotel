from django.contrib.auth.views import LogoutView
from django.urls import path

from . import views as v

urlpatterns = [
    # ลูกค้า
    path("", v.home, name="home"),
    path("hotel/", v.hotel_info, name="hotel_info"),
    path("rooms/", v.rooms, name="rooms"),
    path("facilities/", v.facilities, name="facilities"),
    path("news/", v.news, name="news"),
    path("contact/", v.contact, name="contact"),
    path("booking/", v.booking_search, name="booking_search"),
    path("booking/rooms/", v.booking_rooms, name="booking_rooms"),
    path("booking/guest/", v.booking_guest, name="booking_guest"),
    path("booking/review/", v.booking_review, name="booking_review"),
    path("booking/<int:pk>/payment/", v.payment_choose, name="payment_choose"),
    path("booking/<int:pk>/payment/transfer/", v.payment_transfer, name="payment_transfer"),
    path("booking/<int:pk>/payment/<str:kind>/", v.payment_online, name="payment_online"),
    path("booking/<int:pk>/done/", v.booking_done, name="booking_done"),
    # ผู้ดูแลระบบ
    path("manage/login/", v.ManageLoginView.as_view(), name="manage_login"),
    path("manage/logout/", LogoutView.as_view(next_page="manage_login"), name="manage_logout"),
    path("manage/", v.manage_dashboard, name="manage_dashboard"),
    path("manage/housekeeping/", v.manage_housekeeping, name="manage_housekeeping"),
    path("manage/rooms/", v.manage_rooms, name="manage_rooms"),
    path("manage/roomtypes/new/", v.manage_roomtype_form, name="manage_roomtype_new"),
    path("manage/roomtypes/<int:pk>/", v.manage_roomtype_form, name="manage_roomtype_edit"),
    path("manage/rooms/new/", v.manage_room_form, name="manage_room_new"),
    path("manage/rooms/<int:pk>/", v.manage_room_form, name="manage_room_edit"),
    path("manage/rooms/<int:pk>/delete/", v.manage_room_delete, name="manage_room_delete"),
    path("manage/bookings/", v.manage_bookings, name="manage_bookings"),
    path("manage/bookings/<int:pk>/", v.manage_booking_detail, name="manage_booking_detail"),
    path("manage/bookings/<int:pk>/edit/", v.manage_booking_edit, name="manage_booking_edit"),
    path("manage/members/", v.manage_members, name="manage_members"),
    path("manage/members/<int:pk>/", v.manage_member_detail, name="manage_member_detail"),
    path("manage/payments/", v.manage_payments, name="manage_payments"),
    path("manage/payments/<int:pk>/", v.manage_payment_update, name="manage_payment_update"),
    path("manage/reports/", v.manage_reports, name="manage_reports"),
]
