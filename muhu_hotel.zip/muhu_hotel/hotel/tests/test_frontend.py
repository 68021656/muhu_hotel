"""Customer UI and existing booking contracts; no production database writes."""
from datetime import date, timedelta
from decimal import Decimal
from tempfile import TemporaryDirectory

from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import Client, TestCase, override_settings
from django.urls import reverse

from hotel.models import Booking, Guest, HK_OOO, Payment, Room, RoomType


class CustomerFrontendTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.kind = RoomType.objects.create(name='Test Retreat', description='A quiet room', price=Decimal('1500'), capacity=2)
        cls.room = Room.objects.create(number='T101', room_type=cls.kind)
        cls.staff = get_user_model().objects.create_user('ui-staff', password='test-only-password', is_staff=True)

    def setUp(self):
        self.ci = date.today() + timedelta(days=30)
        self.co = self.ci + timedelta(days=2)

    def dates(self, **overrides):
        data = {'check_in': self.ci.isoformat(), 'check_out': self.co.isoformat(), 'guests': 2}
        return data | overrides

    def create_booking(self, client=None):
        client = client or self.client
        self.assertRedirects(client.post(reverse('booking_search'), self.dates()), reverse('booking_rooms'))
        response = client.get(reverse('booking_rooms'))
        self.assertContains(response, 'Test Retreat')
        self.assertContains(response, '3,000.00')
        self.assertRedirects(client.post(reverse('booking_rooms'), {'room_type': self.kind.pk}), reverse('booking_guest'))
        self.assertRedirects(client.post(reverse('booking_guest'), {'name': 'UI Test Guest', 'phone': '0800000000', 'email': 'guest@example.com'}), reverse('booking_review'))
        self.assertContains(client.get(reverse('booking_review')), 'UI Test Guest')
        response = client.post(reverse('booking_review'))
        booking = Booking.objects.latest('pk')
        self.assertRedirects(response, reverse('payment_choose', args=[booking.pk]))
        self.assertEqual(booking.total, Decimal('3000'))
        self.assertEqual(booking.guests, 2)
        return booking

    def test_public_pages_and_customer_assets(self):
        for name in ['home', 'hotel_info', 'rooms', 'facilities', 'news', 'contact', 'booking_search']:
            with self.subTest(page=name):
                response = self.client.get(reverse(name))
                self.assertEqual(response.status_code, 200)
                self.assertContains(response, 'luxury.css')
                self.assertContains(response, 'luxury.js')
                self.assertContains(response, 'id="main-content"')
                self.assertContains(response, 'id="primary-navigation"')
        response = self.client.get(reverse('rooms'))
        self.assertContains(response, f'id="room-detail-{self.kind.pk}"')
        self.assertContains(response, 'Test Retreat')
        self.assertContains(response, '1,500')

    def test_invalid_dates_and_guest_count(self):
        for data in [self.dates(check_in=(date.today()-timedelta(days=1)).isoformat()), self.dates(check_out=self.ci.isoformat()), self.dates(check_out=(self.ci-timedelta(days=1)).isoformat()), self.dates(guests=0), self.dates(guests=11)]:
            with self.subTest(data=data):
                response = self.client.post(reverse('booking_search'), data)
                self.assertEqual(response.status_code, 200)
                self.assertTrue(response.context['form'].errors)
                self.assertContains(response, 'field-errors')

    def test_availability_excludes_maintenance_capacity_and_overlap(self):
        guest = Guest.objects.create(name='Existing', phone='1', email='existing@example.com')
        Booking.objects.create(guest=guest, room=self.room, check_in=self.ci, check_out=self.co, total=3000)
        self.client.post(reverse('booking_search'), self.dates())
        self.assertContains(self.client.get(reverse('booking_rooms')), 'ไม่มีห้องว่าง')
        Booking.objects.all().delete()
        self.room.hk_status = HK_OOO
        self.room.save()
        self.assertContains(self.client.get(reverse('booking_rooms')), 'ไม่มีห้องว่าง')
        self.room.hk_status = 1
        self.room.save()
        self.client.post(reverse('booking_search'), self.dates(guests=3))
        self.assertContains(self.client.get(reverse('booking_rooms')), 'ไม่มีห้องว่าง')

    def test_invalid_guest_and_room_selection(self):
        self.client.post(reverse('booking_search'), self.dates())
        response = self.client.post(reverse('booking_rooms'), {'room_type': 999999})
        self.assertContains(response, 'กรุณาเลือกห้องพัก')
        self.client.post(reverse('booking_rooms'), {'room_type': self.kind.pk})
        response = self.client.post(reverse('booking_guest'), {'name': '', 'phone': '', 'email': 'wrong'})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.context['form'].errors)
        self.assertEqual(Booking.objects.count(), 0)

    def test_cash_booking_and_session_access(self):
        booking = self.create_booking()
        response = self.client.post(reverse('payment_choose', args=[booking.pk]), {'method': 'cash'})
        self.assertRedirects(response, reverse('booking_done', args=[booking.pk]))
        response = self.client.get(reverse('booking_done', args=[booking.pk]))
        self.assertContains(response, booking.reference)
        self.assertContains(response, 'สถานะการจอง')
        self.assertEqual(Client().get(reverse('booking_done', args=[booking.pk])).status_code, 404)
        # Existing backend clears state after creation: sequential replay redirects.
        self.assertRedirects(self.client.post(reverse('booking_review')), reverse('booking_search'))
        self.assertEqual(Booking.objects.count(), 1)

    def test_online_success_preserves_submitter_contract(self):
        booking = self.create_booking()
        for method in ['card', 'qr']:
            with self.subTest(method=method):
                response = self.client.post(reverse('payment_choose', args=[booking.pk]), {'method': method})
                url = reverse('payment_online', args=[booking.pk, method])
                self.assertRedirects(response, url)
                self.assertContains(self.client.get(url), 'name="result" value="success"')
                self.assertRedirects(self.client.post(url, {'result': 'success'}), reverse('booking_done', args=[booking.pk]))
                booking.payment.refresh_from_db()
                self.assertEqual(booking.payment.status, Payment.PAID)

    def test_online_failure(self):
        booking = self.create_booking()
        self.client.post(reverse('payment_choose', args=[booking.pk]), {'method': 'card'})
        response = self.client.post(reverse('payment_online', args=[booking.pk, 'card']), {'result': 'fail'}, follow=True)
        self.assertContains(response, 'ชำระเงินไม่สำเร็จ')
        booking.payment.refresh_from_db()
        self.assertEqual(booking.payment.status, Payment.PENDING)

    def test_transfer_upload(self):
        booking = self.create_booking()
        self.assertRedirects(self.client.post(reverse('payment_choose', args=[booking.pk]), {'method': 'transfer'}), reverse('payment_transfer', args=[booking.pk]))
        with TemporaryDirectory() as media, override_settings(MEDIA_ROOT=media):
            upload = SimpleUploadedFile('test-slip.txt', b'test-only proof')
            self.assertRedirects(self.client.post(reverse('payment_transfer', args=[booking.pk]), {'slip': upload}), reverse('booking_done', args=[booking.pk]))
            booking.payment.refresh_from_db()
            self.assertTrue(booking.payment.slip.name)
            self.assertEqual(booking.payment.status, Payment.PENDING)

    def test_guarded_booking_pages(self):
        for name in ['booking_rooms', 'booking_guest', 'booking_review']:
            self.assertRedirects(self.client.get(reverse(name)), reverse('booking_search'))

    def test_staff_presentation_and_pages_remain_available(self):
        response = self.client.get(reverse('manage_login'))
        self.assertContains(response, 'class="management"')
        self.assertNotContains(response, 'class="site-header"')
        self.client.force_login(self.staff)
        for name in ['manage_dashboard', 'manage_housekeeping', 'manage_rooms', 'manage_bookings', 'manage_members', 'manage_payments', 'manage_reports']:
            with self.subTest(page=name):
                self.assertEqual(self.client.get(reverse(name)).status_code, 200)
