from datetime import date

from django import forms

from .models import Booking, Guest, Payment, Room, RoomType
from .utils import available_rooms


def _date_widget():
    return forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d")


class SearchForm(forms.Form):
    check_in = forms.DateField(label="วันเข้าพัก", widget=_date_widget())
    check_out = forms.DateField(label="วันออก", widget=_date_widget())
    guests = forms.IntegerField(label="จำนวนผู้เข้าพัก", min_value=1, max_value=10, initial=2)

    def clean(self):
        data = super().clean()
        ci, co = data.get("check_in"), data.get("check_out")
        if ci and ci < date.today():
            self.add_error("check_in", "ไม่สามารถเลือกวันที่ที่ผ่านมาแล้วได้")
        if ci and co and co <= ci:
            self.add_error("check_out", "วันออกต้องอยู่หลังวันเข้าพัก")
        return data


class GuestForm(forms.ModelForm):
    class Meta:
        model = Guest
        fields = ["name", "phone", "email"]


class PaymentMethodForm(forms.Form):
    method = forms.ChoiceField(label="ช่องทางชำระเงิน", choices=Payment.METHOD_CHOICES, widget=forms.RadioSelect)


class SlipForm(forms.Form):
    slip = forms.FileField(label="แนบสลิปโอนเงิน")


# ---------- ส่วนผู้ดูแลระบบ ----------
class RoomTypeForm(forms.ModelForm):
    class Meta:
        model = RoomType
        fields = ["name", "description", "price", "capacity"]
        widgets = {"description": forms.Textarea(attrs={"rows": 3})}


class RoomForm(forms.ModelForm):
    class Meta:
        model = Room
        fields = ["number", "room_type", "hk_status", "note"]


class BookingEditForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ["room", "check_in", "check_out", "guests"]
        widgets = {"check_in": _date_widget(), "check_out": _date_widget()}

    def clean(self):
        data = super().clean()
        ci, co, room = data.get("check_in"), data.get("check_out"), data.get("room")
        if ci and co:
            if co <= ci:
                self.add_error("check_out", "วันออกต้องอยู่หลังวันเข้าพัก")
            elif room and not available_rooms(ci, co, exclude_booking=self.instance).filter(pk=room.pk).exists():
                self.add_error("room", "ห้องนี้ไม่ว่างในช่วงวันที่เลือก")
        return data


class PaymentStatusForm(forms.ModelForm):
    class Meta:
        model = Payment
        fields = ["status"]
