# Illustrative photography

These are illustrative stock photographs, not verified MUHU Hotel photographs.
Replace with approved hotel photography before launch. Photo IDs are retained for provenance.

- `hotel-hero.jpg`: https://images.unsplash.com/photo-1571896349842-33c89424de2d (2200px, quality 85)
- `room-standard.jpg`: https://images.unsplash.com/photo-1611892440504-42a792e24d32 (1000px, quality 82)
- `room-deluxe.jpg`: https://images.unsplash.com/photo-1566665797739-1674de7a421a (1000px, quality 82)
- `room-suite.jpg`: https://images.unsplash.com/photo-1582719478250-c89cae4dc85b (1000px, quality 82)

Source: Unsplash images CDN. Retrieved 2026-11-01.
The original logo and favicon were retained. Google Fonts remain externally hosted with system fallbacks.
