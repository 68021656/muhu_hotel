(() => {
  'use strict';
  const body = document.body;
  const header = document.querySelector('[data-site-header]');
  const toggle = document.querySelector('[data-menu-toggle]');
  const nav = document.getElementById('primary-navigation');
  const setMenu = open => {
    if (!toggle || !nav) return;
    nav.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.querySelector('.sr-only').textContent = open ? 'ปิดเมนู' : 'เปิดเมนู';
  };
  if (header) {
    const updateHeader = () => header.classList.toggle('scrolled', window.scrollY > 24);
    updateHeader();
    window.addEventListener('scroll', updateHeader, { passive: true });
  }
  toggle?.addEventListener('click', () => setMenu(toggle.getAttribute('aria-expanded') !== 'true'));
  nav?.addEventListener('click', event => { if (event.target.closest('a')) setMenu(false); });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && toggle?.getAttribute('aria-expanded') === 'true') {
      setMenu(false); toggle.focus();
    }
  });
  window.matchMedia('(min-width: 701px)').addEventListener('change', () => setMenu(false));
  // Native date inputs retain platform date pickers and server-side validation.
  const localISO = date => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  const nextDate = iso => {
    const [y, m, d] = iso.split('-').map(Number);
    const next = new Date(y, m - 1, d + 1, 12);
    return localISO(next);
  };
  document.querySelectorAll('.luxury form[data-date-form]').forEach(form => {
    const ci = form.querySelector('[name=check_in]');
    const co = form.querySelector('[name=check_out]');
    if (!ci || !co) return;
    const feedback = form.querySelector('.date-feedback');
    const update = () => {
      ci.min = localISO(new Date());
      co.min = ci.value ? nextDate(ci.value) : nextDate(ci.min);
      const invalid = ci.value && co.value && co.value <= ci.value;
      co.setCustomValidity(invalid ? 'วันออกต้องอยู่หลังวันเข้าพัก' : '');
      if (feedback) feedback.textContent = invalid ? 'กรุณาเลือกวันออกหลังวันเข้าพัก' : '';
    };
    ci.addEventListener('change', update); co.addEventListener('change', update);
    form.addEventListener('submit', update); update();
  });
  document.querySelectorAll('.field').forEach(field => {
    const input = field.querySelector('input, select, textarea');
    if (!input) return;
    const descriptions = [];
    const error = field.querySelector('.field-errors');
    const help = field.querySelector('.help-text');
    if (error && error.textContent.trim()) { input.setAttribute('aria-invalid', 'true'); descriptions.push(error.id); }
    if (help) descriptions.push(help.id);
    if (descriptions.length) input.setAttribute('aria-describedby', descriptions.join(' '));
  });
  // A synchronous per-form guard catches repeated clicks; delay disabling so the
  // browser still serializes the clicked submitter (including payment result).
  const resetForm = form => {
    delete form.dataset.submitting;
    form.removeAttribute('aria-busy');
    form.querySelectorAll('[data-submit-lock]').forEach(button => {
      button.disabled = false; button.removeAttribute('data-submit-lock');
      if (button.dataset.originalHtml) button.innerHTML = button.dataset.originalHtml;
    });
    const status = form.querySelector('.submit-status');
    if (status) status.textContent = '';
  };
  document.querySelectorAll('.luxury form[method="post"]').forEach(form => {
    form.addEventListener('submit', event => {
      if (event.defaultPrevented) return;
      if (!form.checkValidity()) { event.preventDefault(); form.reportValidity(); return; }
      if (form.dataset.submitting) { event.preventDefault(); return; }
      form.dataset.submitting = 'true';
      form.setAttribute('aria-busy', 'true');
      setTimeout(() => {
        form.querySelectorAll('button[type=submit], input[type=submit]').forEach(button => {
          button.dataset.submitLock = 'true'; button.disabled = true;
          if (button === event.submitter && button.tagName === 'BUTTON') {
            button.dataset.originalHtml = button.innerHTML;
            button.textContent = 'กำลังดำเนินการ…';
          }
        });
      }, 0);
    });
  });
  window.addEventListener('pageshow', () => document.querySelectorAll('form[data-submitting]').forEach(resetForm));
  document.querySelectorAll('input[type=password]').forEach(input => {
    if (input.closest('.password-wrap')) return;
    const wrap = document.createElement('div'); wrap.className = 'password-wrap';
    input.parentNode.insertBefore(wrap, input); wrap.append(input);
    const button = document.createElement('button'); button.type = 'button'; button.className = 'password-toggle';
    button.textContent = 'แสดง'; button.setAttribute('aria-label', 'แสดงรหัสผ่าน'); button.setAttribute('aria-pressed', 'false');
    button.addEventListener('click', () => {
      const show = input.type === 'password'; input.type = show ? 'text' : 'password';
      button.textContent = show ? 'ซ่อน' : 'แสดง'; button.setAttribute('aria-pressed', String(show));
      button.setAttribute('aria-label', show ? 'ซ่อนรหัสผ่าน' : 'แสดงรหัสผ่าน');
    }); wrap.append(button);
  });
  const openers = new WeakMap();
  const syncDialogLock = () => { document.documentElement.style.overflow = document.querySelector('dialog[open]') ? 'hidden' : ''; };
  const show = (dialog, opener) => {
    if (!dialog || typeof dialog.showModal !== 'function') return;
    openers.set(dialog, opener); dialog.showModal(); syncDialogLock();
  };
  document.querySelectorAll('[data-dialog-open]').forEach(button => button.addEventListener('click', () => show(document.getElementById(button.dataset.dialogOpen), button)));
  document.querySelectorAll('dialog').forEach(dialog => {
    dialog.addEventListener('close', () => { syncDialogLock(); openers.get(dialog)?.focus(); });
    dialog.addEventListener('click', event => {
      if (event.target !== dialog) return;
      const rect = dialog.getBoundingClientRect();
      if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close();
    });
    dialog.querySelectorAll('[data-dialog-close]').forEach(button => button.addEventListener('click', event => { event.preventDefault(); dialog.close(); }));
  });
  document.querySelectorAll('[data-lightbox]').forEach(button => button.addEventListener('click', () => {
    const dialog = document.getElementById('room-lightbox');
    const img = button.querySelector('img');
    if (!dialog || !img) return;
    const target = dialog.querySelector('[data-lightbox-image]');
    target.src = img.currentSrc || img.src; target.alt = img.alt; show(dialog, button);
  }));
  // Visible by default; only animate content below the viewport after setup.
  if (body.classList.contains('luxury') && 'IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add('revealed'); observer.unobserve(entry.target); }
    }), { threshold: .08 });
    document.querySelectorAll('[data-reveal]').forEach(element => {
      if (element.getBoundingClientRect().top > window.innerHeight) { element.classList.add('reveal-pending'); observer.observe(element); }
    });
  }
  document.querySelectorAll('.luxury .room-card-image').forEach(container => {
    const img = container.querySelector('img');
    if (!img || img.complete) return;
    container.classList.add('image-loading');
    const done = () => container.classList.remove('image-loading');
    img.addEventListener('load', done, { once: true });
    img.addEventListener('error', done, { once: true });
  });
  // A bundled image keeps the layout useful even without external photography.
  document.querySelectorAll('.luxury img').forEach(img => img.addEventListener('error', () => {
    if (img.dataset.fallback) return;
    img.dataset.fallback = 'true'; img.classList.add('image-unavailable');
    img.alt = 'MUHU Hotel — ไม่สามารถโหลดภาพประกอบได้';
    img.src = body.dataset.imageFallback;
  }));
})();
