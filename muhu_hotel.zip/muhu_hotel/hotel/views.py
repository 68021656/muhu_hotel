from datetime import date, timedelta
from decimal import Decimal

from django.contrib import messages
from django.contrib.auth.decorators import user_passes_test
from django.contrib.auth.views import LoginView
from django.core.mail import send_mail
from django.db import transaction
from django.db.models import ProtectedError, Q, Sum
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .forms import (BookingEditForm, GuestForm, PaymentMethodForm, PaymentStatusForm, RoomForm,
                    RoomTypeForm, SearchForm, SlipForm)
from .models import (HK_CHOICES, HK_CLEAN, HK_CLEANING, HK_DIRTY, HK_OOO, Booking, Guest, Payment, Room,
                     RoomType)
from .utils import available_rooms


# =====================================================================
#  ส่วนลูกค้า (Customer)
# =====================================================================
def home(request):
    return render(request, "hotel/home.html")


def hotel_info(request):
    return render(request, "hotel/hotel_info.html")


def rooms(request):
    return render(request, "hotel/rooms.html", {"types": RoomType.objects.all()})


def facilities(request):
    return render(request, "hotel/facilities.html")


def news(request):
    return render(request, "hotel/news.html")


def contact(request):
    return render(request, "hotel/contact.html")


def _search_from_session(request):
    s = request.session.get("search")
    if not s:
        return None
    return {
        "check_in": date.fromisoformat(s["check_in"]),
        "check_out": date.fromisoformat(s["check_out"]),
        "guests": s["guests"],
    }


def booking_search(request):
    """เลือกวันเข้าพักและจำนวนผู้เข้าพัก"""
    initial = _search_from_session(request) or {}
    form = SearchForm(request.POST or None, initial=initial)
    if request.method == "POST" and form.is_valid():
        d = form.cleaned_data
        request.session["search"] = {
            "check_in": d["check_in"].isoformat(),
            "check_out": d["check_out"].isoformat(),
            "guests": d["guests"],
        }
        return redirect("booking_rooms")
    return render(request, "hotel/booking_search.html", {"form": form, "step": 1})


def booking_rooms(request):
    """ตรวจสอบห้องว่าง -> มีห้องว่างหรือไม่ -> เลือกห้องพัก"""
    s = _search_from_session(request)
    if not s:
        return redirect("booking_search")
    nights = (s["check_out"] - s["check_in"]).days
    avail = available_rooms(s["check_in"], s["check_out"])
    options = []
    for rt in RoomType.objects.all():
        count = avail.filter(room_type=rt).count()
        if count and rt.capacity >= s["guests"]:
            options.append({"type": rt, "count": count, "total": rt.price * nights})
    if request.method == "POST" and options:
        chosen = request.POST.get("room_type", "")
        if any(str(o["type"].id) == chosen for o in options):
            request.session["room_type"] = int(chosen)
            return redirect("booking_guest")
        messages.error(request, "กรุณาเลือกห้องพัก")
    return render(request, "hotel/booking_rooms.html",
                  {"search": s, "nights": nights, "options": options, "step": 2})


def _booking_state(request):
    s = _search_from_session(request)
    rt_id = request.session.get("room_type")
    if not s or not rt_id:
        return None
    rt = RoomType.objects.filter(pk=rt_id).first()
    if not rt:
        return None
    nights = (s["check_out"] - s["check_in"]).days
    return {"search": s, "type": rt, "nights": nights, "total": rt.price * nights,
            "guest": request.session.get("guest")}


def booking_guest(request):
    """กรอกข้อมูลผู้จอง"""
    state = _booking_state(request)
    if not state:
        return redirect("booking_search")
    form = GuestForm(request.POST or None, initial=state["guest"] or {})
    if request.method == "POST" and form.is_valid():
        request.session["guest"] = form.cleaned_data
        return redirect("booking_review")
    return render(request, "hotel/booking_guest.html", {"form": form, "state": state, "step": 3})


def booking_review(request):
    """ตรวจสอบรายละเอียดการจอง -> สร้างการจอง (รอชำระเงิน)"""
    state = _booking_state(request)
    if not state or not state["guest"]:
        return redirect("booking_search")
    if request.method == "POST":
        s, g = state["search"], state["guest"]
        with transaction.atomic():
            room = (available_rooms(s["check_in"], s["check_out"])
                    .filter(room_type=state["type"]).order_by("number").first())
            if not room:
                messages.error(request, "ขออภัย ห้องประเภทนี้เพิ่งถูกจองไป กรุณาเลือกใหม่")
                return redirect("booking_rooms")
            guest = Guest.objects.filter(phone=g["phone"]).first()
            if guest:
                guest.name, guest.email = g["name"], g["email"]
                guest.save()
            else:
                guest = Guest.objects.create(**g)
            booking = Booking.objects.create(
                guest=guest, room=room, check_in=s["check_in"], check_out=s["check_out"],
                guests=s["guests"], total=state["total"])
            Payment.objects.create(booking=booking, amount=booking.total)
        for key in ("search", "room_type", "guest"):
            request.session.pop(key, None)
        request.session["my_bookings"] = request.session.get("my_bookings", []) + [booking.pk]
        return redirect("payment_choose", pk=booking.pk)
    return render(request, "hotel/booking_review.html", {"state": state, "step": 4})


def _my_booking(request, pk):
    if pk not in request.session.get("my_bookings", []):
        raise Http404
    booking = get_object_or_404(Booking.objects.select_related("guest", "room__room_type", "payment"), pk=pk)
    if booking.status == Booking.CANCELLED:
        raise Http404
    return booking


def payment_choose(request, pk):
    """เลือกช่องทางชำระเงิน"""
    booking = _my_booking(request, pk)
    form = PaymentMethodForm(request.POST or None, initial={"method": booking.payment.method or None})
    if request.method == "POST" and form.is_valid():
        method = form.cleaned_data["method"]
        payment = booking.payment
        payment.method = method
        payment.status = Payment.PENDING
        payment.save()
        if method == Payment.TRANSFER:
            return redirect("payment_transfer", pk=pk)
        if method in (Payment.CARD, Payment.QR):
            return redirect("payment_online", pk=pk, kind=method)
        return redirect("booking_done", pk=pk)  # เงินสดที่โรงแรม -> บันทึกสถานะรอชำระเงิน
    return render(request, "hotel/payment_choose.html", {"booking": booking, "form": form, "step": 5})


def payment_transfer(request, pk):
    """โอนเงินผ่านธนาคาร -> แนบสลิป -> เจ้าหน้าที่ตรวจสอบสลิปและยอดเงิน"""
    booking = _my_booking(request, pk)
    form = SlipForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        booking.payment.slip = form.cleaned_data["slip"]
        booking.payment.method = Payment.TRANSFER
        booking.payment.status = Payment.PENDING
        booking.payment.save()
        return redirect("booking_done", pk=pk)
    return render(request, "hotel/payment_transfer.html", {"booking": booking, "form": form, "step": 5})


def payment_online(request, pk, kind):
    """บัตรเครดิต/เดบิต (Payment Gateway) และ QR PromptPay — หน้าจำลองผลการชำระเงิน"""
    if kind not in (Payment.CARD, Payment.QR):
        raise Http404
    booking = _my_booking(request, pk)
    if request.method == "POST":
        if request.POST.get("result") == "success":
            booking.payment.method = kind
            booking.payment.status = Payment.PAID
            booking.payment.save()
            return redirect("booking_done", pk=pk)
        messages.error(request, "ชำระเงินไม่สำเร็จ กรุณาเลือกช่องทางชำระเงินอีกครั้ง")
        return redirect("payment_choose", pk=pk)
    return render(request, "hotel/payment_online.html", {"booking": booking, "kind": kind, "step": 5})


def booking_done(request, pk):
    """ยืนยันการจอง"""
    booking = _my_booking(request, pk)
    return render(request, "hotel/booking_done.html", {"booking": booking, "step": 6})


# =====================================================================
#  ส่วนผู้ดูแลระบบ (Admin)
# =====================================================================
staff_required = user_passes_test(lambda u: u.is_active and u.is_staff, login_url="manage_login")


class ManageLoginView(LoginView):
    template_name = "manage/login.html"
    redirect_authenticated_user = True

    def form_valid(self, form):
        if not form.get_user().is_staff:
            form.add_error(None, "บัญชีนี้ไม่มีสิทธิ์ผู้ดูแลระบบ")
            return self.form_invalid(form)
        return super().form_valid(form)


@staff_required
def manage_dashboard(request):
    ctx = {
        "pending_bookings": Booking.objects.filter(status=Booking.PENDING).count(),
        "pending_payments": Payment.objects.filter(status=Payment.PENDING).exclude(booking__status=Booking.CANCELLED).count(),
        "dirty_rooms": Room.objects.filter(hk_status=HK_DIRTY).count(),
    }
    return render(request, "manage/dashboard.html", ctx)


# ---------- จัดการระบบแม่บ้าน ----------
@staff_required
def manage_housekeeping(request):
    if request.method == "POST":
        room = get_object_or_404(Room, pk=request.POST.get("room_id"))
        action = request.POST.get("action")
        if room.hk_status == HK_OOO:
            messages.error(request, f"ห้อง {room.number} อยู่ระหว่างซ่อมบำรุง")
        elif action == "assign":
            room.assigned_to = request.POST.get("assigned_to", "").strip()
            room.save()
            messages.success(request, f"มอบหมายงานห้อง {room.number} ให้ {room.assigned_to or '-'} แล้ว")
        elif action == "start":
            room.hk_status = HK_CLEANING
            room.save()
            messages.success(request, f"ห้อง {room.number}: เริ่มทำความสะอาด")
        elif action == "ready":
            room.hk_status = HK_CLEAN
            room.assigned_to = ""
            room.save()
            messages.success(request, f"ห้อง {room.number}: ตรวจสอบแล้ว พร้อมเปิดให้ใช้งาน")
        return redirect("manage_housekeeping")
    today = date.today()
    occupied = set(Booking.objects.filter(status=Booking.CONFIRMED, check_in__lte=today, check_out__gt=today)
                   .values_list("room_id", flat=True))
    status = request.GET.get("status", "")
    qs = Room.objects.select_related("room_type")
    if status.isdigit():
        qs = qs.filter(hk_status=int(status))
    cards = [{"room": r, "occupied": r.id in occupied} for r in qs]
    return render(request, "manage/housekeeping.html",
                  {"cards": cards, "status": status, "hk_choices": HK_CHOICES})


# ---------- จัดการข้อมูลห้องพัก ----------
@staff_required
def manage_rooms(request):
    return render(request, "manage/rooms.html",
                  {"types": RoomType.objects.all(), "rooms": Room.objects.select_related("room_type")})


@staff_required
def manage_roomtype_form(request, pk=None):
    obj = get_object_or_404(RoomType, pk=pk) if pk else None
    form = RoomTypeForm(request.POST or None, instance=obj)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "บันทึกข้อมูลประเภทห้องเรียบร้อยแล้ว")
        return redirect("manage_rooms")
    return render(request, "manage/form.html",
                  {"form": form, "title": "แก้ไขประเภทห้องพัก" if obj else "เพิ่มประเภทห้องพัก", "back": "manage_rooms"})


@staff_required
def manage_room_form(request, pk=None):
    obj = get_object_or_404(Room, pk=pk) if pk else None
    form = RoomForm(request.POST or None, instance=obj)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "บันทึกข้อมูลห้องพักเรียบร้อยแล้ว")
        return redirect("manage_rooms")
    return render(request, "manage/form.html",
                  {"form": form, "title": f"แก้ไขห้อง {obj.number}" if obj else "เพิ่มห้องพัก", "back": "manage_rooms"})


@staff_required
@require_POST
def manage_room_delete(request, pk):
    room = get_object_or_404(Room, pk=pk)
    try:
        room.delete()
        messages.success(request, f"ลบห้อง {room.number} เรียบร้อยแล้ว")
    except ProtectedError:
        messages.error(request, f"ลบห้อง {room.number} ไม่ได้ เพราะมีประวัติการจอง")
    return redirect("manage_rooms")


# ---------- จัดการรายการจอง ----------
def _email_confirmation(booking):
    send_mail(
        subject=f"ยืนยันการจอง MUHU Hotel เลขที่ {booking.reference}",
        message=(
            f"เรียน คุณ{booking.guest.name}\n\n"
            f"MUHU Hotel ยืนยันการจองของท่านเรียบร้อยแล้ว\n"
            f"เลขที่การจอง: {booking.reference}\n"
            f"ห้องพัก: {booking.room.room_type.name} (ห้อง {booking.room.number})\n"
            f"เข้าพัก: {booking.check_in:%d/%m/%Y}  ออก: {booking.check_out:%d/%m/%Y} ({booking.nights} คืน)\n"
            f"ผู้เข้าพัก: {booking.guests} คน\n"
            f"ยอดรวม: {booking.total:,.2f} บาท\n\n"
            f"ขอบคุณที่เลือก MUHU Hotel"
        ),
        from_email=None,
        recipient_list=[booking.guest.email],
        fail_silently=True,
    )


@staff_required
def manage_bookings(request):
    status = request.GET.get("status", "")
    q = request.GET.get("q", "").strip()
    qs = Booking.objects.select_related("guest", "room__room_type", "payment")
    if status:
        qs = qs.filter(status=status)
    if q:
        qs = qs.filter(Q(reference__icontains=q) | Q(guest__name__icontains=q) | Q(guest__phone__icontains=q))
    return render(request, "manage/bookings.html",
                  {"bookings": qs, "status": status, "q": q, "statuses": Booking.STATUS_CHOICES})


@staff_required
def manage_booking_detail(request, pk):
    booking = get_object_or_404(Booking.objects.select_related("guest", "room__room_type", "payment"), pk=pk)
    if request.method == "POST":
        action = request.POST.get("action")
        if action == "confirm":
            booking.status = Booking.CONFIRMED
            booking.save()
            _email_confirmation(booking)
            messages.success(request, f"ยืนยันการจอง {booking.reference} และส่งอีเมลถึงลูกค้าแล้ว")
        elif action == "cancel":
            booking.status = Booking.CANCELLED
            booking.save()
            messages.success(request, f"ยกเลิกการจอง {booking.reference} แล้ว")
        return redirect("manage_booking_detail", pk=pk)
    return render(request, "manage/booking_detail.html", {"b": booking})


@staff_required
def manage_booking_edit(request, pk):
    """แก้ไขข้อมูลการจอง (กรณีข้อมูลไม่ถูกต้องหลังโทรยืนยัน)"""
    booking = get_object_or_404(Booking.objects.select_related("guest", "room__room_type"), pk=pk)
    form = BookingEditForm(request.POST or None, instance=booking)
    gform = GuestForm(request.POST or None, instance=booking.guest, prefix="g")
    if request.method == "POST" and form.is_valid() and gform.is_valid():
        gform.save()
        b = form.save(commit=False)
        b.total = b.room.room_type.price * b.nights
        b.save()
        b.payment.amount = b.total
        b.payment.save()
        messages.success(request, "แก้ไขข้อมูลการจองเรียบร้อยแล้ว")
        return redirect("manage_booking_detail", pk=pk)
    return render(request, "manage/form.html",
                  {"form": form, "form2": gform, "title": f"แก้ไขการจอง {booking.reference}",
                   "back": "manage_bookings"})


# ---------- จัดการข้อมูลสมาชิก ----------
@staff_required
def manage_members(request):
    q = request.GET.get("q", "").strip()
    qs = Guest.objects.all()
    if q:
        qs = qs.filter(Q(name__icontains=q) | Q(phone__icontains=q) | Q(email__icontains=q))
    return render(request, "manage/members.html", {"members": qs, "q": q})


@staff_required
def manage_member_detail(request, pk):
    guest = get_object_or_404(Guest, pk=pk)
    form = GuestForm(request.POST or None, instance=guest)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "บันทึกข้อมูลสมาชิกเรียบร้อยแล้ว")
        return redirect("manage_member_detail", pk=pk)
    history = guest.bookings.select_related("room__room_type", "payment")
    return render(request, "manage/member_detail.html", {"form": form, "guest": guest, "history": history})


# ---------- จัดการการชำระเงิน ----------
@staff_required
def manage_payments(request):
    status = request.GET.get("status", "")
    qs = Payment.objects.select_related("booking__guest", "booking__room")
    if status:
        qs = qs.filter(status=status)
    return render(request, "manage/payments.html",
                  {"payments": qs.order_by("-id"), "status": status, "statuses": Payment.STATUS_CHOICES})


@staff_required
def manage_payment_update(request, pk):
    payment = get_object_or_404(Payment.objects.select_related("booking__guest"), pk=pk)
    form = PaymentStatusForm(request.POST or None, instance=payment)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "อัปเดตสถานะการชำระเงินเรียบร้อยแล้ว")
        return redirect("manage_payments")
    return render(request, "manage/payment_update.html", {"form": form, "p": payment})


# ---------- จัดการรายงาน ----------
def _parse(value, default):
    try:
        return date.fromisoformat(value)
    except (TypeError, ValueError):
        return default


@staff_required
def manage_reports(request):
    today = date.today()
    start = _parse(request.GET.get("start"), today.replace(day=1))
    end = _parse(request.GET.get("end"), today)
    bookings = (Booking.objects.select_related("guest", "room__room_type", "payment")
                .filter(check_in__gte=start, check_in__lte=end))
    valid = bookings.exclude(status=Booking.CANCELLED)
    revenue = valid.filter(payment__status=Payment.PAID).aggregate(s=Sum("total"))["s"] or Decimal(0)
    expected = valid.aggregate(s=Sum("total"))["s"] or Decimal(0)
    by_type = [
        {"name": rt.name, "count": valid.filter(room__room_type=rt).count(),
         "sum": valid.filter(room__room_type=rt).aggregate(s=Sum("total"))["s"] or 0}
        for rt in RoomType.objects.all()
    ]
    room_status = [{"label": label, "count": Room.objects.filter(hk_status=k).count()} for k, label in HK_CHOICES]
    return render(request, "manage/reports.html", {
        "start": start, "end": end, "bookings": bookings, "total_count": valid.count(),
        "cancelled": bookings.filter(status=Booking.CANCELLED).count(),
        "revenue": revenue, "expected": expected, "by_type": by_type, "room_status": room_status,
        "total_rooms": Room.objects.count(),
    })
