# MUHU Hotel — Frontend redesign

Implemented 2026-11-01. Django Templates, existing URLs, POST field names, CSRF, Session keys, models, migrations and booking business logic are retained.

## What changed

- Charcoal, champagne and ivory design system, Playfair Display, Inter and Thai typography.
- Full-width hero, floating availability form posting directly to the existing booking search view.
- Sticky navigation with scroll state, mobile menu, keyboard focus and Escape support.
- Database-backed room listing and availability cards with 3 desktop / 2 tablet / 1 mobile columns.
- Room details use native modal dialogs on the existing rooms URL. Lightbox returns keyboard focus correctly.
- Existing six-step booking flow retained, with sticky summaries, accessible field errors and clear booking/payment status.
- Form submission guard and busy state reduce repeated clicks. Named payment submitter values are preserved.
- Native date pickers with client date constraints, retaining existing server validation.
- Reduced-motion support, below-fold lazy images, image loading placeholders, failure fallback and skip link.
- Photography is stored locally. All photographs are explicitly illustrative. See `hotel/static/hotel/img/luxury/SOURCES.md`.
- Staff templates retain the original CSS. `manage/base.html` sets a separate body class; shared form markup retains all original form fields.

## Existing files modified (18)

Under `hotel/templates/hotel/`:

- `base.html`
- `home.html`
- `rooms.html`
- `hotel_info.html`
- `facilities.html`
- `contact.html`
- `news.html`
- `booking_base.html`
- `booking_search.html`
- `booking_rooms.html`
- `booking_guest.html`
- `booking_review.html`
- `booking_done.html`
- `payment_choose.html`
- `payment_transfer.html`
- `payment_online.html`
- `_form.html`

Also: `hotel/templates/manage/base.html` (body class only).

## New files

- `hotel/static/hotel/css/luxury.css`
- `hotel/static/hotel/js/luxury.js`
- `hotel/templates/hotel/components/navbar.html`
- `hotel/templates/hotel/components/footer.html`
- `hotel/templates/hotel/components/booking_search.html`
- `hotel/templates/hotel/components/booking_summary.html`
- `hotel/templates/hotel/components/room_card.html`
- `hotel/templates/hotel/components/room_image.html`
- `hotel/templates/hotel/components/lightbox.html`
- `hotel/templates/hotel/components/stay_cta.html`
- `hotel/static/hotel/img/luxury/`: four illustrative JPEGs and `SOURCES.md`
- `hotel/tests/__init__.py`
- `hotel/tests/test_frontend.py`
- This document and `docs/previews/` screenshots.

No original files were deleted or moved. Original `style.css`, logo and favicon are unchanged.

## Run and test

From the project directory:

```sh
python3 manage.py check
python3 manage.py test hotel.tests --verbosity 1
python3 manage.py runserver
```

Open http://127.0.0.1:8000/ and use a hard refresh if the browser has cached old CSS.
No migration or seed command is required for the frontend update. Do not reseed the existing database to preview it.

Verification completed:

- Django system check passed; all 38 templates compiled.
- 10 automated tests passed, including invalid dates/guests, room availability, invalid room/guest selection, cash/card/QR/transfer, failed payment, session ownership, sequential submission replay and staff pages.
- Browser tested the complete booking → card simulation → confirmation flow against `/tmp/muhu-frontend-ui-test.sqlite3`, isolated from the original database. Total: 1,500 × 2 nights = 3,000; the named success submitter reached the backend correctly.
- Home, room listing and booking review checked at 360, 390, 768, 1024 and 1440 CSS pixels without horizontal overflow. Room grid was changed to use two columns through 1100px.
- About, facilities, contact, news and booking search checked at 360px without horizontal overflow.
- Mobile menu opening and Escape closing verified. Room details and lightbox opening, closing and focus restoration verified.
- No console errors in the final home/rooms check.
- Browser testing uses Chromium; native Safari/iOS and Android devices have not been physically tested.

## Existing limitations and launch content

- Booking remains one room at a time. The room count is displayed honestly as 1 room per booking.
- A client submission lock does not guarantee server idempotency across simultaneous requests, tabs or network retries. Backend protection requires a separate change.
- Card/QR payment is still a simulation; the interface labels it as such. Transfer account information is not configured.
- Contact information and social media accounts were not supplied. No fictitious telephone, email, address or social links are presented.
- Room dimensions and per-room amenities do not exist in the schema. The UI does not invent them.
- Customer account authentication, registration, profile and booking history are not present in the backend and were not added.
- Homepage editorial room names follow the original three categories; if categories change, update these editorial highlights. Actual prices and availability are read from the database on listing/booking pages.
- Replace stock photos with verified hotel photos and complete the contact information before public launch.
- Google Fonts use an external stylesheet with local system font fallbacks.

## Backup

Original templates and static files were archived before editing:

`/tmp/muhu-hotel-before-luxury-20261101.tar.gz`

Review an archive extraction in a separate temporary directory before selectively restoring files. The archive does not include or alter the database.
